var jsonTreeData = [
    {id:"L3529107364353923",text:"Application",href:"#",leaf:false, children:
        [{id:"L3529403918353923","text":"0","href":"content-page.html","leaf":true},
        {id:"L3529722176353923","text":"Attachments","href":"content-page.html","leaf":true},
        {id:"L3530018708353923","text":"Home","href":"content-page.html","leaf":true},
        {id:"L3530332166353923","text":"Login","href":"content-page.html","leaf":true}
        ]
    },
    {id:"L3530625904353923","text":"Built-in Functionality","href":"content-page.html","leaf":false,"children":
        [{id:"L3530925656353923","text":"Cascading Select Lists","href":"content-page.html","leaf":true},
        {id:"L3531206431353923","text":"Item Types","href":"content-page.html","leaf":true},
        {id:"L3531528286353923","text":"Select List and Multiple Select List","href":"content-page.html","leaf":true}
        ]
    },
    {id:"L3531805295353923","text":"Ext Components","href":"content-page.html","leaf":false,"children":
        [{id:"L3532114644353923","text":"Accordion Nested Templates","href":"content-page.html","leaf":true},
        {id:"L3532428551353923","text":"Low Hanging Fruit","href":"content-page.html","leaf":true},
        {id:"L3532701558353924","text":"TabPanel Nested Templates","href":"content-page.html","leaf":true},
        {id:"L3533007496353924","text":"TabPanel Plugin","href":"content-page.html","leaf":true}
        ]
    },
    {id:"L3533316414353924","text":"Plugins","href":"content-page.html","leaf":false,"children":
        [{id:"L3533632264353924","text":"Dynamic Actions on Complex Plugins","href":"content-page.html","leaf":true}
        ]
    },
    {id:"L3533924579353924","text":"Templates","href":"content-page.html","leaf":false,"children":
        [{id:"L3534207126353924","text":"Button Templates","href":"content-page.html","leaf":true},
        {id:"L3534532191353924","text":"Calendar Templates","href":"content-page.html","leaf":true},
        {id:"L3534801924353924","text":"Dynamic Action on Combo","href":"content-page.html","leaf":true},
        {id:"L3535132271353924","text":"Label Templates","href":"content-page.html","leaf":true},
        {id:"L3535424049353924","text":"Region Templates","href":"content-page.html","leaf":true,"isCurrent":true},
        {id:"L3535706944353924","text":"Standard List Templates","href":"content-page.html","leaf":true},
        {id:"L3536007295353924","text":"Standard Reports Templates","href":"content-page.html","leaf":true},
        {id:"L3536305607353926","text":"Toolbar","href":"content-page.html","leaf":true}
        ]
    },
    {id:"L3536624198353926","text":"Unspecified","href":"content-page.html","leaf":false,"children":
        [{id:"L3536914811353926","text":"Application Users","href":"content-page.html","leaf":true},
        {id:"L3537214040353926","text":"Commonwealth Games 2010 Medal Talley","href":"content-page.html","leaf":true},
        {id:"L3537505894353926","text":"Edit Application User","href":"content-page.html","leaf":true},
        {id:"L3537826551353926","text":"GridPanel","href":"content-page.html","leaf":true},
        {id:"L3538132423353926","text":"Logger (5 min)","href":"content-page.html","leaf":true},
        {id:"L3538404298353926","text":"Tabular Form","href":"content-page.html","leaf":true},
        {id:"L3538729921353926","text":"Tabular Form","href":"content-page.html","leaf":true},
        {id:"L3539022005353926","text":"Tree Page","href":"content-page.html","leaf":true}
        ]
    }
];
