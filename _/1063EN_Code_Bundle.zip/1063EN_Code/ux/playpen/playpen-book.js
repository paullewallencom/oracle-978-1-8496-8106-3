function findPosX(obj){
   var lEl=$x(obj),leftOff=0,curleft=0;
   if(lEl.x){
     return lEl.x;
   }else if(lEl.offsetParent){
     while(lEl.offsetParent){
       if(lEl.style.left){
          curleft = Ext.fly(obj).getX() - Ext.fly(lEl).getX();
          return curleft;
       }
       lEl=lEl.offsetParent;
     }
     curleft = Ext.fly(obj).getX() - Ext.fly(lEl).getX();
   }
   return curleft;
}


/**
 * @ignore
 * */
function findPosY(obj){
   var lEl = $x(obj),curtop = 0;
   if (lEl.y){
     return lEl.y;
   } else if (lEl.offsetParent) {
     while (lEl.offsetParent){
       if ( lEl.style.top )  {
          curtop = Ext.fly(obj).getY() - Ext.fly(lEl).getY() - 5;

          // adjust for APEX adjustment
          curtop = curtop - obj.offsetHeight - 35;
          return curtop;
       }
       lEl = lEl.offsetParent;
     }
     curtop = Ext.fly(obj).getY() - Ext.fly(lEl).getY() - 5;
     // adjust for APEX adjustment
     curtop = curtop - obj.offsetHeight - 5;
     return curtop;
   }
   return curtop;
}

/**
 * dhtml_MenuOpen has issues with Ext layouts, due possibly to a mixture of absolute and relative offsets.
 * This resolves the issue.
 */

function dhtml_MenuOpen(pThis,pThat,pSub,pDir){
    var lNamespace;
    if($x(pThat)) {
        // set event namespace name on 'menu_keys_' + [ID of the current menu]
        lNamespace = 'menu_keys_' + pThat;
        document.onclick = dhtml_DocMenuCheck;
        apex.jQuery(document).unbind('keydown.' + lNamespace + '_esc').bind('keydown.' + lNamespace + '_esc', function(event) {
            if (event.which === 27) {
                app_AppMenuMultiClose();
                dhtml_CloseAllSubMenus();
                document.onclick = null;
            }
        });

        // if we're not opening a sub-menu, close all sub menus and set global for current menu to pThat (just an id)
        if(!pSub) {
            dhtml_CloseAllSubMenus();
            gCurrentAppMenu = pThat;
        }else{
            // get the level of the sub-menu to open
            var l_Level = parseInt($x(pThat).getAttribute("htmldb:listlevel"),10);
            // in case a sub-menu is already displayed, hide it
            var l_Temp = gSubMenuArray[l_Level];
            if(l_Temp) {
                $x_Hide(l_Temp);
            }
            // set global for sub menu to the sub-menu to open
            gSubMenuArray[l_Level] = $x(pThat);
        }
        $gCurrentAnchorList = apex.jQuery('#' + pThat).children().children().filter('a');

        // add event handlers for keystrokes
        apex.jQuery(document).unbind('keydown.' + lNamespace).bind('keydown.' + lNamespace, function(event){
            // setup key codes for specific keys supported (down, up, left, right, return)
            var lKeyCodes = [40,38,37,39,13];
            // check if the menu is visible and that the key pressed is one of the supported keys
            if (apex.jQuery('#' + pThat + ':visible').filter('ul')[0] && apex.jQuery.inArray(event.which, lKeyCodes) !== -1 ) {
                dhtml_KeyAction(event, lNamespace);
            }
        });

        // pThat stores ID of menu to open, store the DOM element of the main menu in local variable
        var lMenu = $x(pThat);
        // add the menu to the DOM
        document.body.appendChild(lMenu);

//         if(!pDir || pDir == 'Right') {
//             lMenu.style.position = "absolute";
//             lMenu.style.top = (parseInt(findPosY(pThis),10)+"px");
//             lMenu.style.left = (parseInt(findPosX(pThis),10)+"px");
//         }else if(pDir == 'Bottom') {
//           lMenu.style.position = "absolute";
//           lMenu.style.top = (parseInt(findPosY(pThis),10) + parseInt(pThis.offsetHeight,10)+"px");
//           lMenu.style.left = (parseInt(findPosX(pThis),10)+"px");
//         }else if(pDir == 'BottomRight') {
//           lMenu.style.position = "absolute";
//           lMenu.style.top = (parseInt(findPosY(pThis),10) + parseInt(pThis.offsetHeight,10)+"px");
//           lMenu.style.left = (parseInt(findPosX(pThis),10) - parseInt(pThis.offsetWidth,10)+"px");
//         }else{
//           lMenu.style.position = "absolute";
//           lMenu.style.top = (parseInt(findPosY(pThis),10)+"px");
//           lMenu.style.left = (parseInt(findPosX(pThis),10) + parseInt(pThis.offsetWidth,10)+"px");
//         }

// new code start

        var elX = Ext.fly(pThis).getX();
        var elY = Ext.fly(pThis).getY();
        if(!pDir || pDir == 'Right') {
            lMenu.style.position = "absolute";
            lMenu.style.top = (elY+"px");
            lMenu.style.left = (elX+"px");
        }else if(pDir == 'Bottom') {
          lMenu.style.position = "absolute";
          lMenu.style.top = (elY + parseInt(pThis.offsetHeight,10)+"px");
          lMenu.style.left = (elX+"px");
        }else if(pDir == 'BottomRight') {
          lMenu.style.position = "absolute";
          lMenu.style.top = (elY + parseInt(pThis.offsetHeight,10)+"px");
          lMenu.style.left = (elX - parseInt(pThis.offsetWidth,10)+"px");
        }else{
          lMenu.style.position = "absolute";
          lMenu.style.top = (elY+"px");
          lMenu.style.left = (elX + parseInt(pThis.offsetWidth,10)+"px");
        }
// new code end


        // show the menu
        $x_Show(lMenu);
        dhtml_FixLeft(pThis, lMenu, pDir);
        htmldb_IE_Select_Item_Fix(lMenu);
    }
    return;
}


Ext.override(Ext.Button, {
    /**
     * @cfg {Mixed} transformEl
     * <p>Specify the id of a DOM element that is already present in the document that specifies some
     * structural markup for this component.</p><div><ul>
     * <li><b>Description</b> : <ul>
     * <div class="sub-desc">Used when markup is the same as Button markup to activate as Ext component.</div>
     * </ul></li>
     * <li><b>Notes</b> : <ul>
     * <div class="sub-desc">When using this config, render and applyTo are ignored.</div>
     * </ul></li>
     * </ul></div>
     */
    // private
    isRendered: false,
    arrowSelector: 'em',

    initComponent: function(){
        if (this.transformEl) {
            this.isRendered = true;
            this.applyTo = this.transformEl;
            delete this.transformEl;
        }
        this.addEvents(
            /**
             * @event click
             * Fires when this button is clicked
             * @param {Button} this
             * @param {EventObject} e The click event
             */
            'click',
            /**
             * @event toggle
             * Fires when the 'pressed' state of this button changes (only if enableToggle = true)
             * @param {Button} this
             * @param {Boolean} pressed
             */
            'toggle',
            /**
             * @event mouseover
             * Fires when the mouse hovers over the button
             * @param {Button} this
             * @param {Event} e The event object
             */
            'mouseover',
            /**
             * @event mouseout
             * Fires when the mouse exits the button
             * @param {Button} this
             * @param {Event} e The event object
             */
            'mouseout',
            /**
             * @event menushow
             * If this button has a menu, this event fires when it is shown
             * @param {Button} this
             * @param {Menu} menu
             */
            'menushow',
            /**
             * @event menuhide
             * If this button has a menu, this event fires when it is hidden
             * @param {Button} this
             * @param {Menu} menu
             */
            'menuhide',
            /**
             * @event menutriggerover
             * If this button has a menu, this event fires when the mouse enters the menu triggering element
             * @param {Button} this
             * @param {Menu} menu
             * @param {EventObject} e
             */
            'menutriggerover',
            /**
             * @event menutriggerout
             * If this button has a menu, this event fires when the mouse leaves the menu triggering element
             * @param {Button} this
             * @param {Menu} menu
             * @param {EventObject} e
             */
            'menutriggerout'
        );
        if(this.menu){
            this.menu = Ext.menu.MenuMgr.get(this.menu);
        }
        if(Ext.isString(this.toggleGroup)){
            this.enableToggle = true;
        }
    },

    onRender: function(ct, position){
        if (!this.template) {
            if (!Ext.Button.buttonTemplate) {
                // hideous table template
                Ext.Button.buttonTemplate = new Ext.Template(
                    '<table id="{4}" cellspacing="0" class="x-btn {3}"><tbody class="{1}">',
                    '<tr><td class="x-btn-tl"><i>&#160;</i></td><td class="x-btn-tc"></td><td class="x-btn-tr"><i>&#160;</i></td></tr>',
                    '<tr><td class="x-btn-ml"><i>&#160;</i></td><td class="x-btn-mc"><em class="{2}" unselectable="on"><button type="{0}"></button></em></td><td class="x-btn-mr"><i>&#160;</i></td></tr>',
                    '<tr><td class="x-btn-bl"><i>&#160;</i></td><td class="x-btn-bc"></td><td class="x-btn-br"><i>&#160;</i></td></tr>',
                    '</tbody></table>');
                Ext.Button.buttonTemplate.compile();
            }
            this.template = Ext.Button.buttonTemplate;
        }

        var btn, targs = this.getTemplateArgs();

        if (!this.isRendered) {
            if (position) {
                btn = this.template.insertBefore(position, targs, true);
            }
            else {
                btn = this.template.append(ct, targs, true);
            }
        }
        else {
            btn = this.el;

            // remove onclick from DOM and make button event
            if (btn.getAttribute('onclick')) {
                var clickString = btn.getAttribute('onclick');

                if (clickString !== '') {
                    btn.dom.removeAttribute('onclick');
                    // use supplied in preference to onclick attribute
                    if (!this.handler) {
                        if (Ext.isIE) {
                            eval("this.on('click', " + clickString + ");");
                        }
                        else {
                            eval("this.on('click', function(){ " + clickString + "});");
                        }
                    }
                }
            }

            // assign text from markup when not specified
            if (!this.text) {
                this.btnEl = btn.child(this.buttonSelector);
                this.text = this.btnEl.dom.innerHTML;
            }

            btn.child('tbody').dom.className = targs[1];

            // Menu - assign class if specified
            if(this.menu && targs[2]){
                btn.child(this.arrowSelector).addClass(targs[2]);
            }

        }

        this.btnEl = this.btnEl || btn.child(this.buttonSelector);
        this.mon(this.btnEl, {
            scope: this,
            focus: this.onFocus,
            blur: this.onBlur
        });

        this.initButtonEl(btn, this.btnEl);

        Ext.ButtonToggleMgr.register(this);
    }
});


// create custom namespace if doesn't exist
Ext.ns('Ext.apex');


// custom container
Ext.apex.Viewport = Ext.extend(Ext.Container, {
    initComponent : function() {
        Ext.apex.Viewport.superclass.initComponent.call(this);

        // APEX specific code
        this.el = Ext.get('wwvFlowForm');
        if(this.el){
            this.el.addClass('x-viewport');
            var debug = Ext.getDom('pdebug');

            if (apex.jQuery) {
                // using APEX 4+
                document.getElementsByTagName('html')[0].className += ' x-viewport';
            } else {
                // earlier versions have debugging embedded in the page
                if (!(debug && (debug.value == 'YES'))) {
                    document.getElementsByTagName('html')[0].className += ' x-viewport';
                }
            }

        } else {
            this.el = Ext.getBody();
            document.getElementsByTagName('html')[0].className += ' x-viewport';
        }
        this.el.setHeight = Ext.emptyFn;
        this.el.setWidth = Ext.emptyFn;
        this.el.setSize = Ext.emptyFn;
        this.el.dom.scroll = 'no';
        this.allowDomMove = false;
        this.autoWidth = true;
        this.autoHeight = true;
        Ext.EventManager.onWindowResize(this.fireResize, this);
        this.renderTo = this.el;
    },

    fireResize : function(w, h){
        this.fireEvent('resize', this, w, h, w, h);
    }
});

// Register container so that lazy instantiation may be used
Ext.reg('apex-viewport', Ext.apex.Viewport);



// create custom namespace if doesn't exist
Ext.ns('Ext.apex.tree');

/**
 * @class Ext.apex.tree.TreePanel
 * @extends Ext.tree.TreePanel
 * <p>The APEX TreePanel highlights the first node with isCurrent set to true.</p>
 */
Ext.apex.tree.TreePanel = Ext.extend(Ext.tree.TreePanel, {
    afterRender : function(){
        Ext.apex.tree.TreePanel.superclass.afterRender.call(this);
        this.highlightCurrentNode();
    },

    highlightCurrentNode: function(){
        var path = this.getCurrentNodePath(this.root.attributes);

        this.expandPath(path, 'id', function(isSuccess, currentNode){
            if (isSuccess) {
                currentNode.select();
                currentNode.ensureVisible();
            }
        });
    },

    getCurrentNodePath: function(node){
        if (node.isCurrent) {
            return this.pathSeparator + node.id;
        }
        else {
            if (node.children) {
                for (var i = 0; node.children.length > i; i += 1) {
                    var result = this.getCurrentNodePath(node.children[i]);
                    if (result) {
                        return this.pathSeparator + node.id + result;
                    }
                }
            }
        }
        // not found
        return null;
    }
});


// Register container so that lazy instantiation may be used
Ext.reg('apex-treepanel', Ext.apex.tree.TreePanel);




Ext.override(Ext.form.ComboBox, {
    applyToMarkup : function(el){
        Ext.form.ComboBox.superclass.applyToMarkup.call(this, el);

        // remove APEX applied class
        Ext.fly(el).removeClass('apex_disabled');

        // get the Ext id for the component
        var x = this.getId();

        // Register customized standard actions for the originating DOM element.
        // Original element has been removed and replaced with ComboBox.
        apex.widget.initPageItem(el, {
            getValue: function(){ return Ext.getCmp(x).getValue();},
            setValue: function(v){Ext.getCmp(x).setValue(v);},
            enable: function(){Ext.getCmp(x).enable();},
            disable: function(){Ext.getCmp(x).disable();},
            show: function(){
                Ext.getCmp(x).show();
                Ext.select(el + '-label').show();
            },
            hide: function(){
                Ext.getCmp(x).hide();
                // hide label - relies on using label templates, and label naming convention
                // could check parent TD for label element for this el, and parent's prev sibling TD for label also.
                Ext.select(el + '-label').hide();
            }
        });


        // trigger APEX DA event when value selected
        this.on('select', function(o,record,index){
            apex.jQuery('#' + o.el.id).trigger('select');
        });

    }
});

Ext.override(Ext.form.ComboBox, {
    oneShot: false,
    setValue : function(v){
        var text = v;
        if(this.valueField){
            var r = this.findRecord(this.valueField, v);
            if(r){
                this.oneShot = false;
                text = r.data[this.displayField];
            } else {

                // do extra step for remote mode
                if (this.mode == 'remote' && this.oneShot == false) {
                    this.oneShot = true;
                    this.store.on('load', this.setValue.createDelegate(this, arguments), null, {single: true});
                    this.store.load({
                        params: {'p_widget_num_return': v}
                    });
                    return;
                } else {
                    this.oneShot = false;
                    if(Ext.isDefined(this.valueNotFoundText)){
                        text = this.valueNotFoundText;
                    }
                }
            }
        }
        this.lastSelectionText = text;
        if(this.hiddenField){
            this.hiddenField.value = Ext.value(v, '');
        }
        Ext.form.ComboBox.superclass.setValue.call(this, text);
        this.value = v;
        return this;
    }
});


var apexInitReport = initReport;
initReport = function(pRegionID, pInternalRegionID, pStyleMouseOver, pStyleChecked) {
   apexInitReport(pRegionID, pInternalRegionID, pStyleMouseOver, pStyleChecked);

   var c = 'report_' + pInternalRegionID + '_catch';

   if (Ext.fly(c)) {
      var p = apex.jQuery('#'+c).parent(); // return parent node as a dom node

      // add a mask when any PPR actions happen
      apex.jQuery(p).bind('apexbeforerefresh', function(){
          new Ext.LoadMask(c).show();
      });
      apex.jQuery(p).bind('apexafterrefresh', function(){
          Ext.apex.Report.init(pRegionID);
      });

      Ext.apex.Report.init(pRegionID);

   }
}

Ext.ns('Ext.apex');
Ext.apex.Report = function(){
    var all = new Ext.util.MixedCollection();

    return {
        register : function(id){
            /**
             * APEX prefixes region numbers with R
             * When Partial Page Refresh is enabled the region has a wrapper element (pprEl).
             */
            all.add(id, {
                rows: 1,
                regionNum: id.substring(1),
                pprEl: 'report_' + id.substring(1) + '_catch'
            });
            return all.get(id);
        },

        get : function(id){
            return all.get(id);
        },

        setRows : function(id, n){
            var el = this.get(id);
            if (!el) {
                el = this.register(id);
            }
            el.rows = n;
        },

        all : all,

        init: function (regionID) {

            var el = this.get(regionID);
            if (el === undefined) el = this.register(regionID);

            // Add go to row functionality
            // My template has a table TR element #REGION_STATIC_ID#-right-ct
            var ct = regionID + '-right-ct';
            if (!Ext.fly(ct)) return;

            var me = this;

            var td = Ext.fly(ct).insertFirst({tag:'td',cls:'pagination'});
            new Ext.form.NumberField({
                renderTo: td,
                allowDecimals: false,
                allowNegative: false,
                value: el.rows,
                submitValue: false, /* *** important *** */
                width:30,
                listeners: {
                    specialkey: function(field, e){
                        if (e.getKey() == e.ENTER) {
                            me.setRows(regionID,this.getRawValue());
                            paginate(el.regionNum,regionID,this.getRawValue(),'This form contains unsaved changes. Press "Ok" to proceed without saving your changes.','Y');
                        }
                    }
                }
            });
            Ext.fly(ct).insertFirst({tag:'td',cls:'pagination', style:'padding-right:3px', html: 'Go to row'});
        }
    };
}();



Ext.ns('Ext.apex');
Ext.apex.IFrameComponent = Ext.extend(Ext.BoxComponent, {
    /**
     * The url to be shown in iframe
     * @type {String}
     */
    url : Ext.SSL_SECURE_URL,

    /**
     * @private Just render an iframe
     */
    onRender : function(ct, position){
        var url = this.url;
        this.el = ct.createChild({tag: 'iframe', id: 'iframe-'+ this.id, frameBorder: 0, src: url});
    }
});
Ext.reg('iframe', Ext.apex.IFrameComponent);

Ext.apex.iFramePanel = function(config){
    return new Ext.Panel(Ext.apply({
        allowDomMove: false,
        animCollapse: false,
        collapsible: true,
        deferIFrame: config.collapsed || false,
        items: [new Ext.apex.IFrameComponent()],
        layout: 'fit',
        titleCollapse: true,
        url: Ext.SSL_SECURE_URL,
        listeners: {
            render: function(p){
                if (this.handles != 'none') {
                    new Ext.Resizable(p.getEl(), {
                        handles: config.handles || 's e se',
                        pinned: true,
                        transparent: true,
                        resizeElement: function(){
                            var box = this.proxy.getBox();
                            p.updateBox(box);
                            if (p.layout) {
                                p.doLayout();
                            }
                            if (Ext.isIE) {
                                this.syncHandleHeight();
                            }
                            return box;
                        }
                    });
                }
            },
            afterrender: function(){
                this.iframe = this.body.child('iframe');
                if (!this.deferIFrame) {
                    this.setSrc(this.url);
                }
            },
            expand: function(){
                if (this.iframe && !this.iframe.rendered) {
                    this.setSrc(this.url);
                }
            }
        },
        setSrc: function(url){
            if (this.rendered && this.iframe) {
                var mask = new Ext.LoadMask(this.body, {
                    removeMask: true
                });
                new Ext.util.DelayedTask(function(){
                    mask.show();
                    new Ext.util.DelayedTask(function(){
                        mask.hide();
                    }).delay(250);
                }).delay(150);
                this.iframe.dom.src = url;
                this.iframe.rendered = true;
            }

            return this;
        }

    }, config));
};



Ext.apex.PopupWindow = Ext.extend(Ext.Window, {
    url: Ext.SSL_SECURE_URL,
    title: document.title,
    width: 700,
    height: 600,
    modal: true,
    initComponent: function(){

        // fixed config, can't be modified externally
        var config = {
            border: false,
            closable: true,
            closeAction: 'close',
            header: true,
            items: [ new Ext.apex.IFrameComponent({ url: this.url }) ],
            layout: 'fit',
            maximizable: true,
            plain: true
        };

        // apply config
        Ext.apply(this, Ext.apply(this.initialConfig, config));

        Ext.apex.PopupWindow.superclass.initComponent.call(this);

        this.addEvents(
        /**
         * @event success
         * Fires when iframed page has been processed successfully.
         * @param {Ext.apex.PopupWindow} this
         */
        'success');

    },
    processSuccessful: function(){
        this.fireEvent("success", this);
        this[this.closeAction]();
    }

});





// create custom namespace if doesn't exist
Ext.ns('Ext.apex');
Ext.apex.init = function() {
    if (Ext.isIE) {
        Ext.BLANK_IMAGE_URL = '/i/1px_trans.gif';
    }

    // Init the singleton.  Any tag-based quick tips will start working.
    Ext.QuickTips.init();

    // Apply a set of config properties to the singleton.
    // Use interceptTitles to pick up title attribute,
    // excepting IE as cannot prevent tooltip appearing also.
    Ext.apply(Ext.QuickTips.getQuickTip(), {
        interceptTitles: (!Ext.isIE),
        maxWidth: 400,
        minWidth: 100,
        showDelay: 50,
        trackMouse: true
    });


    // Convert markup buttons to Ext components
    var els = Ext.select("table.ux-btn-markup", true);
    els.each(function(el){
        var btn = new Ext.Button({transformEl: el});

        switch (btn.getText()) {
            case 'Delete' :        btn.setIconClass('ico-delete'); break;
            case 'Add Row' :       btn.setIconClass('ico-add');    break;
            case 'Cancel' :        btn.setIconClass('ico-cancel'); break;
            case 'Submit' :        btn.setIconClass('ico-submit'); break;
            case 'Apply Changes' : btn.setIconClass('ico-submit'); break;
            case '&lt; Previous' :
                 btn.setIconClass('ico-previous');
                 btn.setText('');
                 break;
            case 'Next &gt;' :
                 btn.setIconClass('ico-next');
                 btn.setText('');
                 break;
            default : break;
        }


    });

}

