Ext.onReady(function(){
    Ext.apex.init();


    // STOP when body does not have id of showViewport
    if (Ext.getBody().id !== "showViewport")
        return;


    var items = [];

    items.push({
        applyTo: 'app-north-panel',
        autoHeight: true,
        autoScroll: false,
        region: 'north',
        style: {
            padding: '0 5px'
        },
        xtype: 'box'
    }, {
        contentEl: 'app-south-panel',
        autoScroll: false,
        height: 30,
        region: 'south',
        style: {
            padding: '0 5px'
        },
        xtype: 'box'
    }, {
        id: 'gen-west-panel',
        contentEl: 'app-west-panel',
        collapseMode: 'mini',
        collapsible: true,
        margins: '0 0 0 5',
        maxSize: 500,
        minSize: 100,
        region: 'west',
        split: true,
        title: 'Navigation',
        width: 250
    });

    // conditionally add east panel if it contains child nodes
    if (Ext.fly('app-east-panel') && Ext.fly('app-east-panel').first()) {
        items.push({
            contentEl: 'app-east-panel',
            collapseMode: 'mini',
            collapsible: true,
            margins: '0 5 0 0',
            maxSize: 500,
            minSize: 100,
            region: 'east',
            split: true,
            title: 'Actions',
            width: 275
        }, {
            id: 'gen-center-panel',
            contentEl: 'app-center-panel',
            region: 'center',
            tbar: {
                hidden: true,
                items: []
            },
            title: document.title,
            xtype: 'panel'
        });
    }
    else {
        items.push({
            id: 'gen-center-panel',
            contentEl: 'app-center-panel',
            region: 'center',
            margins: '0 5 0 0',

            tbar: ['->', {
                text: 'Refresh',
                iconCls: 'x-tbar-loading',
                handler: function(){
                    document.location.reload();
                }
            }, '-', {
                text: 'Feedback',
                iconCls: 'ico-comments',
                handler: function(){
                    new Ext.apex.PopupWindow({
                        iconCls: 'ico-comments',
                        title: 'Feedback: ' + document.title,
                        url: 'f?p=' + Ext.getDom('pFlowId').value + ':feedback:' + Ext.getDom('pInstance').value + ':::102:P102_APPLICATION_ID,P102_PAGE_ID:' + Ext.getDom('pFlowId').value + ',' + Ext.getDom('pFlowStepId').value
                    }).show();
                }
            }, '-', {
                text: 'Print',
                iconCls: 'ico-print',
                handler: function(){
                    // if a custom print function is defined for the page, use it
                    // this allows you to call BI Publisher reports easily
                    if (typeof print_report == 'function') {
                        print_report();
                    }
                    else {
                        print();
                    }
                }
            }, {
                text: 'Help',
                iconCls: 'ico-help',
                handler: function(){
                    new Ext.apex.PopupWindow({
                        iconCls: 'ico-help',
                        modal: false,
                        title: 'Help: ' + document.title,
                        url: 'f?p=' + Ext.getDom('pFlowId').value + ':help:' + Ext.getDom('pInstance').value + ':' + Ext.getDom('pFlowStepId').value
                    }).show();
                }
            }],
            title: document.title,
            xtype: 'panel'
        });
    }

    new Ext.apex.Viewport({
        id: 'page-viewport',
        layout: 'border',
        defaults: {
            animCollapse: false,
            autoScroll: true,
            layout: 'fit'
        },
        items: items
    });

});


