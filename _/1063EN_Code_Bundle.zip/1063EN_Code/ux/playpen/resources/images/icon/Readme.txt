The images in this directory are part of the FamFamFam Silk library located
at http://www.famfamfam.com/lab/icons/silk/

This work is licensed under a Creative Commons Attribution 2.5 License,
see http://creativecommons.org/licenses/by/2.5/