-----------------------------------------------------------------------------
-- Oracle Apex 4-0 with Ext JS
-- https://www.packtpub.com/oracle-application-express-4-0-with-ext-js/book
-----------------------------------------------------------------------------

The Ext JS 3.3.1 JavaScript library has not been included with this code bundle.
You will need to download it from the Sencha website at http://www.sencha.com/products/extjs3/
and extract it into the /ux/extjs folder.

The path for the files should be the same as:

/ux/extjs/adapter/..
/ux/extjs/docs/..
/ux/extjs/examples/..
/ux/extjs/pkgs/..
/ux/extjs/resources/..
/ux/extjs/src/..
/ux/extjs/test/..
/ux/extjs/welcome/..
/ux/extjs/ext-all.js

This will allow the book examples located in /ux/examples/chapterXX/ to work stand-alone.


APEX Temlate Application
------------------------
An APEX template application is located in /apex/playpen_app.sql, showing the examples from the book.

When importing the application using APEX Builder, ensure you run the post-installation scripts when prompted.
This will automatically create database tables, seed data and plugin packages necessary for the examples to work.

You will need to copy the /ux/ folder and its sub-folders onto your web-server.
Refer to the instructions in chapter 1 if you are unsure on how to do this.

